<?php

namespace App\Http\Livewire\Parametros\SitiosTemperatura;

use Livewire\Component;

class EditSitioTemperaturaComponent extends Component
{
    public function render()
    {
        return view('livewire.parametros.sitios-temperatura.edit-sitio-temperatura-component');
    }
}
