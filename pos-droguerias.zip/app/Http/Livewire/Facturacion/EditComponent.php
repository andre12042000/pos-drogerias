<?php

namespace App\Http\Livewire\Facturacion;

use Livewire\Component;

class EditComponent extends Component
{
    public function render()
    {
        return view('livewire.facturacion.edit-component');
    }
}
