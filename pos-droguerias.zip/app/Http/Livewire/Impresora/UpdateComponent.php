<?php

namespace App\Http\Livewire\Impresora;

use Livewire\Component;

class UpdateComponent extends Component
{
    public function render()
    {
        return view('livewire.impresora.update-component');
    }
}
