<?php

namespace App\Http\Livewire\Product;

use Livewire\Component;

class UpdateInventario extends Component
{
    public function render()
    {
        return view('livewire.product.update-inventario');
    }
}
