<?php

$hostname = gethostname();

echo "Nombre del equipo: " . $hostname;

?>
