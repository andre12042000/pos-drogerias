<?php

return [
    'name' => 'Mantenimiento'
];
