<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Mantenimiento\\Providers\\MantenimientoServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Mantenimiento\\Providers\\MantenimientoServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);